"""Runnable teaching agent. Mock model only; no external API or publishing."""
import argparse
import json

NOTES = [
    {"text": "vegan menu costs 20 pounds per guest", "source": "menu.json"},
    {"text": "event capacity is 12 guests", "source": "event.json"},
]

def budget_tool(guests, budget, cost=20):
    if guests <= 0 or budget <= 0 or cost < 0:
        raise ValueError("guests and budget must be positive; cost cannot be negative")
    total = guests * cost
    return {"total": total, "remaining": budget - total, "within_budget": total <= budget}

def retrieve(query, notes):
    return [dict(note) for note in notes if query.lower() in note["text"].lower()]

class MockModel:
    """Replace this explicit interface with a server-side LLM adapter later."""
    def next_action(self, state):
        if "budget" not in state["results"]:
            return {"tool": "budget", "args": {}}
        if "retrieve" not in state["results"]:
            return {"tool": "retrieve", "args": {"query": "vegan"}}
        if not state["results"]["retrieve"]:
            return {"tool": "ask", "args": {"question": "Please provide menu information"}}
        if state["publish_requested"]:
            return {"tool": "publish", "args": {}}
        return {"tool": "finish", "args": {}}

class EventAgent:
    def __init__(self, model=None, notes=None, max_steps=5):
        self.model = model or MockModel()
        self.notes = NOTES if notes is None else notes
        self.max_steps = max_steps

    def run(self, guests, budget, publish_requested=False):
        state = {"guests": guests, "budget": budget, "publish_requested": publish_requested,
                 "results": {}, "log": [], "mode": "mock", "api_cost": 0}
        if guests <= 0 or budget <= 0:
            return dict(state, status="ask", question="人数和预算必须大于零")
        for step in range(max(0, self.max_steps)):
            action = self.model.next_action(state)
            tool, args = action.get("tool"), action.get("args", {})
            if tool == "finish":
                return dict(state, status="done", answer={"budget": state["results"]["budget"],
                    "menu_sources": state["results"]["retrieve"]})
            if tool == "publish":
                return dict(state, status="needs_confirmation", question="仅生成草稿；外部发布需人工确认")
            if tool == "ask":
                return dict(state, status="ask", question=args.get("question", "Please provide details"))
            try:
                if tool == "budget":
                    result = budget_tool(guests, budget)
                elif tool == "retrieve":
                    result = retrieve(args.get("query", ""), self.notes)
                else:
                    return dict(state, status="error", error="unknown tool")
            except (ValueError, TypeError) as error:
                return dict(state, status="error", error=str(error))
            state["results"][tool] = result
            state["log"].append({"step": step + 1, "tool": tool, "args": args, "result": result})
        return dict(state, status="stopped", reason="max_steps")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--guests", type=int, default=12)
    parser.add_argument("--budget", type=float, default=300)
    parser.add_argument("--max-steps", type=int, default=5)
    parser.add_argument("--request-publish", action="store_true")
    args = parser.parse_args()
    result = EventAgent(max_steps=args.max_steps).run(args.guests, args.budget, args.request_publish)
    print(json.dumps(result, ensure_ascii=False, indent=2))
