# 活动运营 Agent · 免费模拟版

这是青云的教学参考项目。使用 Python 标准库，无需 API key。

1. 阅读 main.py 中 budget_tool 的输入输出。
2. 运行 `python3 main.py`，查看预算、来源和日志。
3. 运行 `python3 -m unittest -v` 验证 7 个案例。
4. 改变人数与预算：`python3 main.py --guests 8 --budget 100`。
5. 尝试 `python3 main.py --request-publish` 和 `python3 main.py --max-steps 1`。
6. 为自己的改动新增一个测试，再记录修改理由和输出。

## 数据流

MockModel.next_action → 白名单工具 → 结果写入 state → 模型选择下一步 → 完成 / 追问 / 限制停止。

当前 MockModel 是固定逻辑，检索是关键词匹配；不是实际大模型或向量检索。没有调用 Maps、Booking、邮件或发布 API。成本字段为 0，因为不调用模型。

## 后续接真实模型

先理解并测试流程，再在后端实现 next_action(state) 适配器：只接受白名单结构化工具参数、验证参数、限制步数和费用、记录失败。密钥放后端环境变量。前端展示输出，不能把密钥放到 GitHub Pages 的脚本中。

## 独立交付验收

解释每个工具的输入输出；预算不足给出差额；未知工具拒绝执行；资料带来源；缺资料追问；限制停止；外部发布等待确认；补自己的测试。先学习并修改，再如实描述哪些是模板、哪些是自己实现。
