import unittest
from main import EventAgent, budget_tool
class UnknownModel:
    def next_action(self, state):
        return {"tool": "delete_database"}
class RepeatModel:
    def next_action(self, state):
        return {"tool": "budget", "args": {}}
class AgentTests(unittest.TestCase):
    def test_complete(self):
        result = EventAgent().run(12, 300)
        self.assertEqual(result['status'], 'done')
        self.assertEqual(result['answer']['budget']['remaining'], 60)
        self.assertEqual(result['answer']['menu_sources'][0]['source'], 'menu.json')
    def test_over_budget(self):
        self.assertFalse(budget_tool(12, 100)['within_budget'])
    def test_missing_information(self):
        self.assertEqual(EventAgent().run(0, 300)['status'], 'ask')
    def test_missing_source(self):
        self.assertEqual(EventAgent(notes=[]).run(12, 300)['status'], 'ask')
    def test_unknown_tool(self):
        self.assertEqual(EventAgent(model=UnknownModel()).run(12, 300)['status'], 'error')
    def test_step_limit(self):
        result = EventAgent(model=RepeatModel(), max_steps=2).run(12, 300)
        self.assertEqual(result['status'], 'stopped')
        self.assertEqual(len(result['log']), 2)
    def test_confirmation(self):
        self.assertEqual(EventAgent().run(12, 300, True)['status'], 'needs_confirmation')
if __name__ == '__main__':
    unittest.main()
